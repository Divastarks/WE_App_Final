﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WEApp.Controllers
{
    public class FeedbackController : Controller
    {
        //
        // GET: /Feedback/
        string cs = ConfigurationManager.ConnectionStrings["WEConnectionString"].ConnectionString;
        public ActionResult Feedback()
        {
            return View();
        }
        public int Comments(string Username,string FeedBackRating,string Comments)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_InsertFeedback", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@uname", Username);
            cmd.Parameters.AddWithValue("@feedbackrating", int.Parse(FeedBackRating));
            cmd.Parameters.AddWithValue("@comments", Comments);
            int result = cmd.ExecuteNonQuery();
            return result;
        }

    }
}
