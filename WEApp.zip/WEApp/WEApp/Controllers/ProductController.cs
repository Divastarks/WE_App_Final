﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using WEApp.Models;
namespace WEApp.Controllers
{
    public class ProductController : Controller
    {
        //
        // GET: /Product/
        WE_DevEntities bm = new WE_DevEntities();
        public ActionResult Product()
        {
            return View();
        }
        public ActionResult Index()
        {
            return View();
        }
        public string GetProduct()
        {
            JavaScriptSerializer js = new JavaScriptSerializer();
            object obj = bm.USP_GetProductDetails();
            string result = js.Serialize(obj);
            return result;
        }
    }
}
