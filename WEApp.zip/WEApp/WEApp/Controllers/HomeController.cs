﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WEApp.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        string cs = ConfigurationManager.ConnectionStrings["WEConnectionString"].ConnectionString;
        public ActionResult SignUp()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Dashboard()
        {
            return View();
        }
        public ActionResult Home()
        {
            return View();
        }
       
        public int Register(string username, string mobilenumber, string emailid, string password, string confirmpassword)
        {
            SqlConnection sql = new SqlConnection(cs);
           sql.Open();
           SqlCommand cmd = new SqlCommand("USP_InsertUser", sql);
           cmd.CommandType = CommandType.StoredProcedure;
           cmd.Parameters.AddWithValue("@uname",username);
           cmd.Parameters.AddWithValue("@pass",password);
           cmd.Parameters.AddWithValue("@cpass",confirmpassword);
           cmd.Parameters.AddWithValue("@mobileno",mobilenumber);
           cmd.Parameters.AddWithValue("@email",emailid);
           int result = cmd.ExecuteNonQuery();
           return result;
        }
      public int Sigin(string username,string password)
        {
            int flag = 0;
            SqlConnection sql = new SqlConnection(cs);
            sql.Open();
            SqlCommand cmd = new SqlCommand("USP_ChkLoginUser", sql);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@uname", username);
            cmd.Parameters.AddWithValue("@pass", password);
            int result = (int)cmd.ExecuteScalar();
            if(result>0)
            {
                Session["Username"] = username;
                flag = 1;
            }
            return flag;
        }
        
    }
}
