﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WEApp.Controllers
{
    public class AboutusController : Controller
    {
        //
        // GET: /Aboutus/

        public ActionResult Aboutus()
        {
            return View();
        }

    }
}
