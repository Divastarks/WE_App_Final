﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WEApp.Controllers
{
    public class SponsorshipController : Controller
    {
        //
        // GET: /Sponsorship/
        string cs = ConfigurationManager.ConnectionStrings["WEConnectionString"].ConnectionString;
        public ActionResult SponsorRegistration()
        {
            return View();
        }
        public ActionResult Sponsorship()
        {

            return View();
        }
        public int Registration(string SponsorFirstName,string SponsorLastName,string DOB,string Age,string Occupation,string Mobilenumber,string AadharID,string Address,string SponsorAmount,string CardHolderName,string CardNumber,string ExpiryDate,string CVC,string ProductID)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_InsertSponsor", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@firstname",SponsorFirstName);
            cmd.Parameters.AddWithValue("@lastname",SponsorLastName);
            cmd.Parameters.AddWithValue("@dOB",Convert.ToDateTime(DOB));
            cmd.Parameters.AddWithValue("@age",int.Parse(Age));
            cmd.Parameters.AddWithValue("@occupation",Occupation);
            cmd.Parameters.AddWithValue("@mobileno",long.Parse(Mobilenumber));
            cmd.Parameters.AddWithValue("@aadharId",long.Parse(AadharID));
            cmd.Parameters.AddWithValue("@address",Address);
            cmd.Parameters.AddWithValue("@productID",int.Parse(ProductID));
            cmd.Parameters.AddWithValue("@sponsoramount",decimal.Parse(SponsorAmount));
            cmd.Parameters.AddWithValue("@cardholdername",CardHolderName);
            cmd.Parameters.AddWithValue("@cardnumber",CardNumber);
            cmd.Parameters.AddWithValue("@expirydate",Convert.ToDateTime(ExpiryDate));
             cmd.Parameters.AddWithValue("@cVC",int.Parse(CVC));
             int result = cmd.ExecuteNonQuery();
             return result;
            
        }

        public string GetPickelAmount()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetTotalAmountPickle", con);
            cmd.CommandType = CommandType.StoredProcedure;
            decimal result=(decimal)cmd.ExecuteScalar();
           
            return result.ToString();
        }
        public string GetNapkinAmount()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetTotalAmountNapkin", con);
            cmd.CommandType = CommandType.StoredProcedure;
            decimal result = (decimal)cmd.ExecuteScalar();

            return result.ToString();
        }
        public string GetHandcraftAmount()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetTotalAmountHandcraft", con);
            cmd.CommandType = CommandType.StoredProcedure;
            decimal result = (decimal)cmd.ExecuteScalar();

            return result.ToString();

        }
        public string GetWeavingSareesAmount()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetTotalAmountWeavingSarees", con);
            cmd.CommandType = CommandType.StoredProcedure;
            decimal result = (decimal)cmd.ExecuteScalar();

            return result.ToString();
        }
        public string GetSoapAmount()
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetTotalAmountSoap", con);
            cmd.CommandType = CommandType.StoredProcedure;
            decimal result = (decimal)cmd.ExecuteScalar();

            return result.ToString();
        }
    }
}
