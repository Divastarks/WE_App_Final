﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WEApp.Controllers
{
    public class TeamController : Controller
    {
        //
        // GET: /Team/
        string cs = ConfigurationManager.ConnectionStrings["WEConnectionString"].ConnectionString;
        public ActionResult TeamRegistration()
        {
            return View();
        }
        public ActionResult ProductUpdateForm()
        {
            return View();
        }
        public string Registration(string TeamName,string ExecutiveFirstName,string ExecutiveLastName,string DOB,string Age,string Address,string AadharID,string FatherSpouseName,string Mobilenumber,string Alternatenumber,string AccountNumber,string IFSCCode,string ProductID)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_InsertTeam", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@TeamName", TeamName);
            cmd.Parameters.AddWithValue("@ExecutiveFirstName", ExecutiveFirstName);
            cmd.Parameters.AddWithValue("@ExecutiveLastName", ExecutiveLastName);
            cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(DOB));
            cmd.Parameters.AddWithValue("@Age", int.Parse(Age));
            cmd.Parameters.AddWithValue("@Address", Address);
            cmd.Parameters.AddWithValue("@AadharID", long.Parse(AadharID));
            cmd.Parameters.AddWithValue("@FatherSpouseName", FatherSpouseName);
            cmd.Parameters.AddWithValue("@Mobilenumber", long.Parse(Mobilenumber));
            cmd.Parameters.AddWithValue("@Alternatenumber", long.Parse(Alternatenumber));
            cmd.Parameters.AddWithValue("@AccountNumber", long.Parse(AccountNumber));
            cmd.Parameters.AddWithValue("@IFSCCode", IFSCCode);
            cmd.Parameters.AddWithValue("@ProductID", int.Parse(ProductID));
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@Teamid";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            cmd.Parameters.Add(outPutParameter);
            cmd.ExecuteNonQuery();
            string result = outPutParameter.Value.ToString();
            return result;            
        }
        public int ProductUpdateReg(string Stock, string ProductDescription, string Mobilenumber, string EmailID, string ProductID, string TeamID)
        {

            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_InsertProductUpdate", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Stock", int.Parse(Stock));
            cmd.Parameters.AddWithValue("@ProductDescription", ProductDescription);
            cmd.Parameters.AddWithValue("@Mobilenumber", long.Parse(Mobilenumber));
            cmd.Parameters.AddWithValue("@EmailID", EmailID);
            cmd.Parameters.AddWithValue("@ProductID", int.Parse(ProductID));
            cmd.Parameters.AddWithValue("@TeamID", int.Parse(TeamID));
            

            int result = cmd.ExecuteNonQuery();
            return result;
        }
    }
}
