﻿$(document).ready(function () {
    $("#submit").click(function () {
        var SponsorFirstName = $("#firstname").val();
        var SponsorLastName = $("#lastname").val();
        var Age = $("#age").val();
        var DOB = $("#dob").val();
        var ProductID = $("#product").val();
        var AadharID = $("#aadhar").val();
        var Mobilenumber = $("#mobile").val();
        var Occupation = $("#occupation").val();
        var Address = $("#address").val();
        var SponsorAmount = $("#amount").val();
        var CardHolderName = $("#cardholdername").val();
        var CardNumber = $("#cardnumber").val();
        var CVC = $("#cvc").val();
        var ExpiryDate = $("#expirydt").val();
        //alert(SponsorFirstName + " " + SponsorLastName + " " + Age + " " + DOB + " " + ProductID + " " + AadharID + " " + Mobilenumber + " " + Occupation + " " + Address + " " + SponsorAmount + " " + CardHolderName + " " + CardNumber + " " + CVC + " " + ExpiryDate + " ");

        $.ajax({
            url: '/Sponsorship/Registration',
            async: false,
            type: 'GET',
            data: { "SponsorFirstName": SponsorFirstName, "SponsorLastName": SponsorLastName, "DOB": DOB, "Age": Age, "Occupation": Occupation, "Mobilenumber": Mobilenumber, "AadharID": AadharID, "Address": Address, "ProductID": ProductID, "SponsorAmount": SponsorAmount, "CardHolderName": CardHolderName, "CardNumber": CardNumber, "ExpiryDate": ExpiryDate, "CVC": CVC },
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Registration Done");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));
            }
        });

    });
});