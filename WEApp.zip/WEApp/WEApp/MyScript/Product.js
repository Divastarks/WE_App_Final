﻿$(document).ready(function () { 
    $("#tblProduct").dataTable({

        "ajax": {
            "url": "/Product/GetProduct",
            "dataSrc": ""
        },

        "columns": [
            { "data": "ProductName" },
            { "data": "ProductDescription" },
            { "data": "Stock" },
            { "data": "TeamName" },
            { "data": "EmailID" },
            { "data": "Mobilenumber" }
           
        ]

    });

});
