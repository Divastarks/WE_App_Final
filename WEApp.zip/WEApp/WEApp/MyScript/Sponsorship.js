﻿$(document).ready(function () {
    $("#btnRequestP").click(function () {
        $("#Pickel").text("Requested");
    });
    $("#btnRequestN").click(function () {
        $("#Napkins").text("Requested");
    });
    $("#btnRequestH").click(function () {
        $("#HandCrafts").text("Requested");
    });
    $("#btnRequestS").click(function () {
        $("#Soap").text("Requested");
    });
    $("#btnRequestW").click(function () {
        $("#Weaving").text("Requested");
    });

    GetPickelAmount();
    GetNapkinAmount();
    GetHandcraftAmount();
    GetSoapAmount();
    GetWeavingSareesAmount();

    function GetPickelAmount()
    {

        $.ajax({
            url: '/Sponsorship/GetPickelAmount',
            async: false,
            type: 'GET',
            data: {},
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                var result=JSON.stringify(data);
                $("#PickelAmount").text(result);
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));
            }
        });
    }
    function GetNapkinAmount() {

        $.ajax({
            url: '/Sponsorship/GetNapkinAmount',
            async: false,
            type: 'GET',
            data: {},
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                var result = JSON.stringify(data);
                $("#NapkinAmount").text(result);
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));
            }
        });
    }

    function GetHandcraftAmount() {

        $.ajax({
            url: '/Sponsorship/GetHandcraftAmount',
            async: false,
            type: 'GET',
            data: {},
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                var result = JSON.stringify(data);
                $("#HandcraftAmount").text(result);
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));
            }
        });
    }
    function GetSoapAmount() {

        $.ajax({
            url: '/Sponsorship/GetSoapAmount',
            async: false,
            type: 'GET',
            data: {},
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                var result = JSON.stringify(data);
                $("#SoapAmount").text(result);
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));
            }
        });
    }
    function GetWeavingSareesAmount() {

        $.ajax({
            url: '/Sponsorship/GetWeavingSareesAmount',
            async: false,
            type: 'GET',
            data: {},
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                var result = JSON.stringify(data);
                $("#WeavingSarees").text(result);
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));
            }
        });
    }
  
});










