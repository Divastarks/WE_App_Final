﻿$(document).ready(function (){
    $("#btnsumbit").click(function () {
       
        var username = $("#UserName").val();
        var Mobilenumber = $("#Mobilenumber").val();
        var EmailId = $("#EmailID").val();
        var Password = $("#Password").val();
        var ConfirmPassword = $("#ConfirmPassword").val();
       // alert(username + "\n" + Mobilenumber + "\n" + EmailId + "\n" + Password + "\n" + ConfirmPassword);
        $.ajax({
            url: '/Home/Register',
            async: false,
            type: 'GET',
            data: { "username": username, "mobilenumber": Mobilenumber, "emailid": EmailId, "password": Password, "confirmpassword": ConfirmPassword },
            dataType: 'json',
            contentType: 'appllication/json;charset=utf-8',
            success:function(data)
            {
                alert("Regsitered Successfully");
               
            },
            error:function(request,error)
            {
                alert("Request"+JSON.stringify(request));
            }
        });
    });
});