﻿$(document).ready(function () {
    $("#register").click(function(){
        var TeamName = $("#TeamName").val();
        var ExecutiveFirstName = $("#EFName").val();
        var ExecutiveLastName = $("#Elname").val();
        var DOB=$("#DOB").val();
        var Age=$("#Age").val();
        var Address = $("#Addres").val();
        var Mobilenumber = $("#PhoneNumber").val();
        var Alternatenumber = $("#APNumber").val();
        var AadharID = $("#AdharId").val();
        var FatherSpouseName=$("#FSName").val();
        var AccountNumber = $("#AccNumber").val();
        var IFSCCode = $("#IFCS").val();
        var ProductID = $("#ProductId").val();
  
        //alert(TeamName + " " + ExecutiveFirstName + " " + ExecutiveLastName + " " + DOB + " " + Age + " " + Address + " " + Mobilenumber + " " + Alternatenumber + " " + AadharID + " " + FatherSpouseName + " " + AccountNumber + " " + IFSCCode + " " + ProductID);

        $.ajax({
            url: '/Team/Registration',
            async: false,
            type: 'Get',
            data: { "TeamName": TeamName, "ExecutiveFirstName": ExecutiveFirstName, "ExecutiveLastName": ExecutiveLastName, "DOB": DOB, "Age": Age, "Address": Address, "AadharID": AadharID, "FatherSpouseName": FatherSpouseName, "Mobilenumber": Mobilenumber, "Alternatenumber": Alternatenumber, "AccountNumber": AccountNumber, "IFSCCode": IFSCCode, "ProductID": ProductID },
            dataType:'json',
        contentType: 'application/json;charset=utf-8',
        success: function (data)
        {
            var result = JSON.stringify(data);
            alert("Successfully Registered... Your Team ID : " + result);
            
        },
        error: function(request,error)
        {
            alert("request:"+JSON.stringify(request));
        }


    });
});

});