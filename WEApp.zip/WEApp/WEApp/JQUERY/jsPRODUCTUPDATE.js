﻿$(document).ready(function () {
    $("#btnsubmit").click(function () {
        var TeamID = $("#TeamID").val();
        var Stock = $("#Stock").val();
        var ProductDescription = $("#ProductDescription").val();
        var Mobilenumber = $("#Mobilenumber").val();
        var EmailID = $("#EmailID").val();
        var ProductID = $("#ProductID").val();
        

        //alert(Stock + " " + ProductDescription + " " + Mobilenumber + " " + EmailID + " " + ProductID + " " + TeamID);

        $.ajax({
            url: '/Team/ProductUpdateReg',
            async: false,
            type: 'GET',
            data: { "Stock": Stock, "ProductDescription": ProductDescription, "Mobilenumber": Mobilenumber, "EmailID": EmailID, "ProductID": ProductID, "TeamID": TeamID },
            datatype: 'JSON',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Updation done!!");

            },
            error: function (request, error) {
                alert("Request:" + JSON.stringify(request));
            }
        });

    });
});