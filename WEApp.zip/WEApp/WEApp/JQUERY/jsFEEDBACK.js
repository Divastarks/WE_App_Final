﻿$(document).ready(function () {
    $("#btnsubmit").click(function () {
        var Username = $("#username").val();
        var FeedBackRating = $("input[name='rating']:checked").val();
        var Comments = $("#comments").val();

        //alert(Username + " " + FeedBackRating + " " + Comments);

        $.ajax({
            url: '/Feedback/Comments',
            async: false,
            type:'GET',
            data: { "Username": Username, "FeedBackRating": FeedBackRating, "Comments": Comments },
            datatype:'JSON',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Registration done!!");

            },
            error: function (request, error) {
                alert("Request:" + JSON.stringify(request));
            }
        });

    });
});